<?php
echo 'ok';
unlink("Backup.zip");